const express = require("express");
const app = express();
const https = require("https");
const bodyParser =require("body-parser");
const mongoose = require("mongoose");

app.use(bodyParser.urlencoded({extended:true}));
app.set("view engine", "ejs");
mongoose.connect("mongodb://localhost:27017/newsDB")

const newsSchema = mongoose.Schema({
  title:String,
  category:String,
  content:String
})

const News = mongoose.model("News", newsSchema);

app.get("/", function(req,res){
  News.find(function(err,foundNews){
  res.render("page", {header:"Personal news", newsList:foundNews, name:weatherData.name, country:weatherData.sys.country, description:weatherData.weather[0].description,
     temp:weatherData.main.temp, temp_min:weatherData.main.temp_min, temp_max:weatherData.main.temp_max, speed:weatherData.wind.speed, clouds:weatherData.clouds.all})
  })


  const url = "https://api.openweathermap.org/data/2.5/weather?appid=07e6be11058f287f345016199616cd77&q=Almaty&units=metric"

    https.get(url, function(response){
        //console.log(response)
        response.on("data", function(data){
          //console.log(data)
          const weatherData = JSON.parse(data)
          const country = weatherData.sys.country
          const flag = "http://openweathermap.org/images/flags/" + country.toLowerCase() + ".png"

          res.render("page", {name:weatherData.name, country:weatherData.sys.country, description:weatherData.weather[0].description,
             temp:weatherData.main.temp, temp_min:weatherData.main.temp_min, temp_max:weatherData.main.temp_max, speed:weatherData.wind.speed, clouds:weatherData.clouds.all})



          res.write("<h3>"
                    + weatherData.name + ", "
                    + weatherData.sys.country + ", "
                    + "<img src=" + flag + ">" + " "
                    + weatherData.weather[0].description
                    +  "</h3>")
          res.write("<p>"
                    + weatherData.main.temp + " C temperature from "
                    + weatherData.main.temp_min + " to "
                    + weatherData.main.temp_max + " C, wind "
                    + weatherData.wind.speed + " m/s. clouds "
                    + weatherData.clouds.all + " %, " + "</p>")
          res.send()
        })
      })


})

app.post("/",function(req,res){
  const newsTitle = req.body.title
  const newsCategory = req.body.category
  const newsContent = req.body.content
  const news = new News({
    title: newsTitle,
    category: newsCategory,
    content: newsContent
  })
  news.save()
  res.redirect("/")
})




app.listen(4000,function(){
  console.log("localhost:4000");
})
